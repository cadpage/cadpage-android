package org.htmlcleaner;

/**
 * Marker interface denoting nodes of the document tree
 */
public interface HtmlNode extends BaseToken {
}